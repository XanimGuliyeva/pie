using BethanyPieShop.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

//WebApplication.CreateBuilder(args) initializes the application by creating a WebApplicationBuilder object.
//This builder sets up the services, middleware, and configuration necessary for the application.
//The args parameter allows command-line arguments to influence how the application is configured.

builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
builder.Services.AddScoped<IPieRepository, PieRepository>();


builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<BethanyPieShopDbContext>(options=> {
    options.UseSqlServer(
        builder.Configuration["ConnectionStrings:BethanyPieShopDbContextConnection"]);
});

var app  = builder.Build();

app.UseStaticFiles();

if(app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.MapDefaultControllerRoute();

app.Run(); 