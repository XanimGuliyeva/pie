﻿namespace BethanyPieShop.Models
{
    public class CategoryRepository:ICategoryRepository
    {
        private readonly BethanyPieShopDbContext _bethanyPieShopContext;

        public CategoryRepository(BethanyPieShopDbContext bethanyPieShopContext)
        {
            _bethanyPieShopContext = bethanyPieShopContext;
        }

        public IEnumerable<Category> AllCategories =>
            _bethanyPieShopContext.Categories.OrderBy(p => p.CategoryName);
    }
}
