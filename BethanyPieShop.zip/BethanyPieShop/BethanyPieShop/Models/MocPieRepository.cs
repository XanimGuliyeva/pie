﻿
namespace BethanyPieShop.Models
{
    public class MocPieRepository : IPieRepository
    {
        private readonly ICategoryRepository _categoryRepository=new
            MockCategoryRepository();
        public IEnumerable<Pie> AllPies => 
            new List<Pie>
            {
                new Pie {PieID=1,Name="Fruie pies",Price=15M,ShortDescription="All fruity pies",LongDescription="All fruity pies",Category=_categoryRepository.AllCategories.ToList()[0],ImageUrl="https://images.app.goo.gl/RrK6U8uV2Tma5TRb7",InStock=true,IsPieOfTheWeek=false,ImageThumbnaiUrl="https://"}
            };

        public IEnumerable<Pie> PiesOfWeek
        { 
            get {
                return AllPies.Where(p => p.IsPieOfTheWeek);
                }
        }

        public Pie? GetPieById(int pieid) => AllPies.FirstOrDefault(p => p.PieID == pieid);

        public IEnumerable<Pie> SearchPies(string searchQuery)
        {
            throw new NotImplementedException();
        }
    }
}
