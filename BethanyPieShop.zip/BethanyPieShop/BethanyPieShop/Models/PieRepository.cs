﻿using Microsoft.EntityFrameworkCore;

namespace BethanyPieShop.Models
{
    public class PieRepository:IPieRepository
    {
        private readonly BethanyPieShopDbContext _bethanyPieShopContext;

        public PieRepository(BethanyPieShopDbContext bethanyPieShopContext)
        {
            _bethanyPieShopContext = bethanyPieShopContext;
        }


        public IEnumerable<Pie> AllPies
        {
            get {
                return _bethanyPieShopContext.Pies.Include(c => c.Category);
            }
        }

        public IEnumerable<Pie> PiesOfWeek
        {
            get
            {
                return _bethanyPieShopContext.Pies.Include(c => c.Category).Where(p=>p.IsPieOfTheWeek);
            }
        }

        public Pie? GetPieById(int pieId)
        {
                return _bethanyPieShopContext.Pies.FirstOrDefault(p=>p.PieID==pieId);
            
        }
    }
}
